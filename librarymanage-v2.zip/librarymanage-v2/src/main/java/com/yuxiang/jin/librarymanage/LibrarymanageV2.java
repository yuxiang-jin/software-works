package com.yuxiang.jin.librarymanage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrarymanageV2 {

    public static void main(String[] args) {
        SpringApplication.run(LibrarymanageV2.class, args);
    }

}
