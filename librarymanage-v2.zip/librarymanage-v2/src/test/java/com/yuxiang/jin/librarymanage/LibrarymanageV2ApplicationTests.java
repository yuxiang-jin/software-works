package com.yuxiang.jin.librarymanage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarymanageV2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
