-- 向book_inf表插入数据
insert into book.book_inf2 values
(null, '共产党宣言', '马克思 恩格斯', 18.8),
(null, '资本论', '马克思', 298.8),
(null, '国富论', '亚当斯密', 98.8),
(null, 'Java编程思想', 'Java之父', 98.8),
(null, 'Golang', 'Golang之父', 108.8);