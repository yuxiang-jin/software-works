package com.yuxiang.jin.librarymanage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManageTest {

    @Test
    void contextLoads() {
    }

}
