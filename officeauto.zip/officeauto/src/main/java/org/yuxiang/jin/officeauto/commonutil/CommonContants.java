package org.yuxiang.jin.officeauto.commonutil;

public class CommonContants {

    /**
     * CTRL+SHIFT+Y --> 小写
     * CTRL+SHIFT+X --> 大写
     * 验证码
     */
    public static final String VERIFY_SESSION = "verify_session";

}
