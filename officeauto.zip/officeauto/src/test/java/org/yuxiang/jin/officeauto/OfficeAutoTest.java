package org.yuxiang.jin.officeauto;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfficeAutoTest {

    @Test
    void contextLoads() {
    }

}
